//
//  dayWeatherCollectionViewCell.swift
//  weatherApp
//
//  Created by 김보연 on 11/6/23.
//

import UIKit

import SnapKit
import Then

class dayWeatherCollectionViewCell: UICollectionViewCell {
    
    
    
}
